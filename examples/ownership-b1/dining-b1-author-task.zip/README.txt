AlvenX SpatialSceneLab | B1 dining author task / B1 餐厅人工任务

Requires Blender 5.1.2. Open before.blend, open blender_edit.py in the Text
Editor, Run Script, then open the AlvenX sidebar in the 3D view (N).
Inspect Unresolved (-2). Select a real missing subset in Edit Mode, assign
it to the intended dining object, then translate/rotate, Undo/Redo, save
and reopen. Keep the whole surface folder for the source-index lineage.
The script is MIT source; inspect it before enabling it. Core use is local.

This is the measured INITIAL B1 partition, with 96,518 source faces and
3,605 unresolved faces. It is deliberately not a corrected answer. Do not
use fixed scripted face selections as evidence of improved object quality.
Record operator, actual actions, task time, failures/recovery and outputs.
The published project has NOT completed or timed this human task.

使用 Blender 5.1.2 打开 before.blend，在文本编辑器打开 blender_edit.py，
运行后打开三维视图的 AlvenX 侧栏。检查 Unresolved (-2) 未决区域，按真实
几何判断选面和归属，然后完成变换、撤销/重做、保存重开。保留 surface
目录及来源索引。不要把脚本中的固定选面当成真实边界修正。人工操作和耗时
仍待记录，这个文件是原始 B1 任务起点，不是已经修复好的结果。

Reproduce / 复现:
https://github.com/AlbertXXuu/SpatialSceneLab/blob/main/docs/OWNERSHIP-S2A.md
https://github.com/AlbertXXuu/SpatialSceneLab/blob/main/docs/OWNERSHIP-S2A.zh-CN.md
