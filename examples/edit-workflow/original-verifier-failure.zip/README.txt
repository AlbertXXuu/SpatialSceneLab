Authored MIT S0 combined-study assets, unchanged from the recorded failure.
Baseline blender_scene.py is from SpatialSceneLab commit321ca429b84595dac1b81590b23dbc934222d38b.
Use reports/editing-s1/recheck_assets.py from the current repository.
Pass --project this unpacked folder for the original before/after failure;
pass --project the current source checkout for the repaired pass.
Pass --assets this unpacked folder and --output a new JSON path.
The read-only checker never saves or exports the asset files.
The original blender-verification.json remains failed; corrected checks
are separate evidence. No welded-topology or complete-object claim.
