AlvenX SpatialSceneLab S1 — authored MIT combined study

Open after.blend with Blender 5.1.2; it is the authoritative editable result.
Install blender_edit.py using Preferences > Add-ons > Install from Disk,
or run it in the Blender Text Editor. 3D View > Sidebar > AlvenX exposes
selected-face reassignment, metre/degree rigid edits, native undo/redo,
save and GLB export. Open before.blend to inspect the initial state.

The primary desk region moved +0.25 m world X, -0.10 m world Y. The chair
region rotated 32 degrees about world Z around its bounds centre.
12 then 8 scripted selected faces were reassigned without ground-truth
labels; this validates operation semantics, not segmentation improvement.
Holes and leftover object fragments reflect incomplete B0 selections.

after.glb keeps region identities and appearance; after.identity.json
hash-binds its source-face lineage in native blend face order. GLB does
not contain the native per-face edit attributes. Use .blend for continued
ownership editing. These images are actual fixed-camera CPU renders.

Source, bilingual report and complete regeneration commands:
https://github.com/AlbertXXuu/SpatialSceneLab
docs/EDITING-S1.md / docs/EDITING-S1.zh-CN.md
Reports: reports/EDITING-S1-2026-10-06.md and .zh-CN.md
